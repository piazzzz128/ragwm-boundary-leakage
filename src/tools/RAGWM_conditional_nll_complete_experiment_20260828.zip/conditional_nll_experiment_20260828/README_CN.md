# Conditional-NLL 完整补充实验（2026-08-28）

## 目的

本包只新增一个科学上必要且可解释的 baseline：同位置 Conditional NLL。
它与 GainRatio 使用同一批 target token（均为 target 的第 2 至第 n 个 token）、
同一候选边界、同一 clean-group 校准划分、同一四档目标 FPR、同一反向扫描和
后缀删除规则。唯一差别是打分函数：

- Conditional NLL：`L_c(T|C)`，分数越大越可疑；
- GainRatio：`-(L_u(T)-L_c(T|C))/L_u(T)`，分数越大越可疑。

这个设计可以直接检验 GainRatio 的归一化是否在严格低 FPR 和端到端验证中带来收益。

## 不会做的事情

- 不读取或覆盖 strict-v1 结果；
- 不把旧 frozen threshold 套到 Blackwell 环境的新分数上；
- 不用 verifier、WSN 或 retrieval utility 调阈值；
- 不覆盖现有 GainRatio、random、cross-detector 或 14B 输出；
- 不使用 `token-aligned` 作为论文中的方法名称。

## 一键运行

把整个目录上传到 AutoDL 任意位置，然后执行：

```bash
cd /你上传到的目录/conditional_nll_experiment_20260828
chmod +x run_all.sh
RUN_VERIFIER=1 bash run_all.sh
```

`RUN_VERIFIER=1` 会统一复核 15 个条件（450 个固定 watermark units），会产生 API
调用成本。若只想先完成 GPU 评分、四档清洗、建索引和 retrieval utility，可用：

```bash
RUN_VERIFIER=0 bash run_all.sh
```

之后再运行 `RUN_VERIFIER=1 bash run_all.sh`；已完成的阶段会自动跳过。

如果旧 Oracle 索引不在自动识别的历史目录，可显式指定：

```bash
ORACLE_DB=/你的/oracle/chromadb路径 RUN_VERIFIER=1 bash run_all.sh
```

## 断点续跑

全语料评分按文档保存到独立 JSON。实例中断后重复执行同一条命令即可；程序会验证
campaign ID 和文档 ID 后跳过已完成记录。任何旧目录都不会被删除。新建索引如因中断
不完整，会被移动到本次输出目录的 `quarantine/` 后重新构建，仍可恢复。

## 正式输出

输出根目录固定为：

`/root/autodl-tmp/ragwm_storage/output/conditional_nll_e2e_nf_v1_20260828`

全部完成后，把下面文件下载并发回聊天：

`conditional_nll_results_for_review_20260828.tar.gz`

同时复制终端最后显示的 SHA-256。

## 预期阶段

1. 核查 446 行 frozen score 文件及 3,633 篇 attack input；
2. 在当前 Blackwell 环境重算 446 行 same-position NLL；
3. 按 source document 分组，以 seed 20260714 固定 169/54 clean calibration/holdout；
4. 从当前环境分数冻结 1%、2.5%、5%、10% 四个阈值；
5. 以最宽松阈值只扫描语料一次，并精确派生四档停止结果；
6. 构建四个 3,633 文档的 Contriever/cosine ChromaDB；
7. 在同一批 NFCorpus query 上冻结 retrieval rankings，做 5,000 次 paired bootstrap；
8. 在同一 provider campaign 下复核 Watermarked、Oracle、四档 GainRatio、四档
   Conditional NLL 和五个 matched-random seeds；
9. 生成统一 JSON、SHA-256 manifest 和紧凑回传包。
