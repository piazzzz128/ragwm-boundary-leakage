#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import chromadb

COLLECTION = "nfcorpus_contriever_cosine"


def db_count(path: Path) -> int | None:
    if not path.is_dir(): return None
    try: return int(chromadb.PersistentClient(path=str(path)).get_collection(COLLECTION).count())
    except Exception: return None


def flags(path: Path):
    rows = json.loads(path.read_text(encoding="utf-8"))
    values = [int(r[2][0]) for r in rows]
    if any(value not in (0, 1, 2) for value in values):
        raise RuntimeError(f"Unexpected verifier flag in {path}: {sorted(set(values))}")
    return rows, values


def locate_oracle(old_e2e: Path) -> Path:
    preferred = [old_e2e / "vectorstores/e1_oracle_restore", old_e2e / "vectorstores/e1_oracle"]
    for p in preferred:
        if p.is_dir() and db_count(p) == 3633: return p
    candidates = []
    for p in old_e2e.rglob("*oracle*"):
        if p.is_dir() and db_count(p) == 3633: candidates.append(p)
    unique = sorted(set(candidates))
    if len(unique) == 1: return unique[0]
    raise RuntimeError("Could not uniquely locate the 3,633-document Oracle vectorstore. Candidates: " + repr([str(p) for p in unique]))


def main():
    p = argparse.ArgumentParser(); p.add_argument("--repo", type=Path, required=True); p.add_argument("--old-e2e", type=Path, required=True); p.add_argument("--multi", type=Path, required=True); p.add_argument("--out", type=Path, required=True); p.add_argument("--oracle-db", default="")
    args = p.parse_args()
    e0_db = args.old_e2e / "restored/strict_snapshot/root/autodl-tmp/ragwm_storage/chromadb_db"
    oracle_db = Path(args.oracle_db) if args.oracle_db else locate_oracle(args.old_e2e)
    conditions = {
        "watermarked": e0_db,
        "oracle_restore": oracle_db,
        "gainratio_fpr01": args.multi / "vectorstores/qwen25_7b_fpr01",
        "gainratio_fpr025": args.multi / "vectorstores/qwen25_7b_fpr025",
        "gainratio_fpr05": args.old_e2e / "vectorstores/e2_gainratio_aligned_sensitivity",
        "gainratio_fpr10": args.multi / "vectorstores/qwen25_7b_fpr10",
        "conditional_nll_fpr01": args.out / "vectorstores/conditional_nll_fpr01",
        "conditional_nll_fpr025": args.out / "vectorstores/conditional_nll_fpr025",
        "conditional_nll_fpr05": args.out / "vectorstores/conditional_nll_fpr05",
        "conditional_nll_fpr10": args.out / "vectorstores/conditional_nll_fpr10",
    }
    for seed in (101, 202, 303, 404, 505):
        conditions[f"random_fpr05_seed{seed}"] = args.old_e2e / f"vectorstores/e3_random_aligned_v2_seed_{seed}"
    bad = {name: (str(path), db_count(path)) for name, path in conditions.items() if db_count(path) != 3633}
    if bad: raise RuntimeError("Verifier DB preflight failed: " + json.dumps(bad, indent=2))

    source = args.old_e2e / "conditions/e0_watermarked_before/basepath"
    source_files = {
        "wm_prepare/nfcorpus/wmunit.json": source / "wm_prepare/nfcorpus/wmunit.json",
        "wm_generate/nfcorpus/10/wmuint_doc.json": source / "wm_generate/nfcorpus/10/wmuint_doc.json",
        "wm_generate/nfcorpus/10/wmuint_inject.json": source / "wm_generate/nfcorpus/10/wmuint_inject.json",
    }
    for f in source_files.values():
        if not f.exists(): raise FileNotFoundError(f)
    root = args.out / "verifier_refresh/conditions"; root.mkdir(parents=True, exist_ok=True)
    campaign = {"start_utc": datetime.now(timezone.utc).isoformat(), "conditions": {k: str(v) for k, v in conditions.items()}, "verify_num": 30, "verify_seed": 633, "provider_model": "gpt4o_mini_e2e"}
    (args.out / "verifier_refresh/campaign_manifest_start.json").write_text(json.dumps(campaign, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for name, db in conditions.items():
        condition = root / name; base = condition / "basepath"
        output = base / "wm_generate/nfcorpus/gpt4o_mini_e2e/10/wmuint_verify.json"
        if output.exists():
            rows, fs = flags(output)
            if len(rows) == 30 and fs.count(2) == 0:
                print(f"[SKIP] valid verifier output {name}: WSN={fs.count(1)}"); continue
            quarantine = args.out / "quarantine" / f"verifier_{name}_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
            quarantine.parent.mkdir(parents=True, exist_ok=True); shutil.move(str(condition), str(quarantine))
        for rel, src in source_files.items():
            dst = base / rel; dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src, dst)
        log = condition / "verify.log"; log.parent.mkdir(parents=True, exist_ok=True)
        cmd = [sys.executable, "src/main.py", "--eval_dataset", "nfcorpus", "--eval_model_code", "contriever", "--score_function", "cosine", "--top_k", "5", "--mutual_times", "10", "--model_name_llm", "gpt4o_mini_e2e", "--model_name_rllm", "gpt4o_mini_e2e", "--gpu_id", "0", "--basepath", str(base), "--verify_num", "30", "--verify_seed", "633", "--doc", "0", "--inject", "0", "--verify", "1", "--stat", "0"]
        env = os.environ.copy(); env.update({"PYTHONPATH": str(args.repo), "RAGWM_CHROMA_PATH": str(db), "PYTHONUNBUFFERED": "1", "OMP_NUM_THREADS": "8", "MKL_NUM_THREADS": "8"})
        print(f"[VERIFY] {name}", flush=True)
        with log.open("w", encoding="utf-8") as h:
            proc = subprocess.Popen(cmd, cwd=args.repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            assert proc.stdout is not None
            for line in proc.stdout: print(line, end=""); h.write(line); h.flush()
            code = proc.wait()
        if code != 0: raise RuntimeError(f"Verifier failed for {name}; see {log}")
        if not output.exists(): raise RuntimeError(f"Verifier produced no output for {name}")
        rows, fs = flags(output)
        if len(rows) != 30 or fs.count(2) != 0: raise RuntimeError(f"Invalid verifier output {name}: rows={len(rows)}, unknown={fs.count(2)}")
        print(f"[PASS] {name}: WSN={fs.count(1)}")
    campaign["end_utc"] = datetime.now(timezone.utc).isoformat(); campaign["status"] = "complete"
    (args.out / "verifier_refresh/campaign_manifest_complete.json").write_text(json.dumps(campaign, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("UNIFIED VERIFIER REFRESH PASS")


if __name__ == "__main__": main()
