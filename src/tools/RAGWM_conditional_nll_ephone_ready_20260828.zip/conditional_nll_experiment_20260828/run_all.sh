#!/usr/bin/env bash
set -euo pipefail

STORAGE=${STORAGE:-/root/autodl-tmp/ragwm_storage}
REPO=${REPO:-$STORAGE/repo/ragwm_src}
OLD_E2E=${OLD_E2E:-$STORAGE/output/sanitization_e2e_nf_strict_v1}
MULTI=${MULTI:-$STORAGE/output/sanitization_multibudget_nf_aligned_v1}
OLD_TOOL=${OLD_TOOL:-$REPO/tools/RAGWM_multibudget_v1_20260817}
OUT=${OUT:-$STORAGE/output/conditional_nll_e2e_nf_v1_20260828}
MODEL=${MODEL:-$STORAGE/local_models/Qwen2.5-7B}
SCORES=${SCORES:-$STORAGE/output/semantic_cliff/aligned_sensitivity/nfcorpus_aligned_scores.json}
INPUT=${INPUT:-$OLD_E2E/conditions/e2_gainratio_delete/corpus/watermarked_attack_input.jsonl}
RUN_VERIFIER=${RUN_VERIFIER:-0}
ORACLE_DB=${ORACLE_DB:-}

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$OUT/logs" "$OUT/audit" "$OUT/metrics"

exec > >(tee -a "$OUT/logs/run_all.log") 2>&1

echo "[RUN] $(date -u +%FT%TZ)"
echo "[OUT] $OUT"
echo "[RUN_VERIFIER] $RUN_VERIFIER"

required=(
  "$REPO/src/main.py"
  "$OLD_TOOL/scripts/e2_common_aligned.py"
  "$OLD_TOOL/scripts/evaluate_retrieval_utility_frozen.py"
  "$SCORES"
  "$INPUT"
  "$MODEL/config.json"
)
for path in "${required[@]}"; do
  if [[ ! -e "$path" ]]; then
    echo "[FATAL] Missing required path: $path" >&2
    exit 2
  fi
done

score_sha=$(sha256sum "$SCORES" | awk '{print $1}')
input_sha=$(sha256sum "$INPUT" | awk '{print $1}')
[[ "$score_sha" == "e1c7dbc745a83b473883ccf9c0d6a3c43c1bb7a14fa9f0dda1551b08f92dd218" ]] || {
  echo "[FATAL] Frozen score SHA-256 mismatch: $score_sha" >&2; exit 3;
}
[[ "$input_sha" == "52c72f64043e4a668b5084b75ac0cfa92f63b77c3493875cf788ee5021da8e38" ]] || {
  echo "[FATAL] Attack-input SHA-256 mismatch: $input_sha" >&2; exit 3;
}
[[ "$(wc -l < "$INPUT")" -eq 3633 ]] || {
  echo "[FATAL] Attack input is not 3,633 lines" >&2; exit 3;
}

export PYTHONPATH="$OLD_TOOL/scripts:$REPO:${PYTHONPATH:-}"
export PYTHONUNBUFFERED=1
export TOKENIZERS_PARALLELISM=false
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-8}
export MKL_NUM_THREADS=${MKL_NUM_THREADS:-8}

python "$PACKAGE_DIR/scripts/conditional_pipeline.py" \
  --scores "$SCORES" \
  --input "$INPUT" \
  --model "$MODEL" \
  --out "$OUT" \
  --seed 20260714 \
  --n-boot 5000 \
  --max-steps 8 \
  2>&1 | tee "$OUT/logs/01_conditional_pipeline.log"

python "$PACKAGE_DIR/scripts/build_vectorstores.py" \
  --repo "$REPO" \
  --out "$OUT" \
  --batch-size 32 \
  2>&1 | tee "$OUT/logs/02_build_vectorstores.log"

E0_DB="$OLD_E2E/restored/strict_snapshot/root/autodl-tmp/ragwm_storage/chromadb_db"
if [[ ! -d "$E0_DB" ]]; then
  echo "[FATAL] Missing E0 database: $E0_DB" >&2
  exit 4
fi

UTILITY="$OUT/metrics/retrieval_utility_frozen.json"
if [[ ! -s "$UTILITY" ]]; then
  python "$OLD_TOOL/scripts/evaluate_retrieval_utility_frozen.py" \
    --repo "$REPO" \
    --db "watermarked=$E0_DB" \
    --db "conditional_nll_fpr01=$OUT/vectorstores/conditional_nll_fpr01" \
    --db "conditional_nll_fpr025=$OUT/vectorstores/conditional_nll_fpr025" \
    --db "conditional_nll_fpr05=$OUT/vectorstores/conditional_nll_fpr05" \
    --db "conditional_nll_fpr10=$OUT/vectorstores/conditional_nll_fpr10" \
    --baseline-name watermarked \
    --n-boot 5000 \
    --seed 20260609 \
    --output "$UTILITY" \
    2>&1 | tee "$OUT/logs/03_retrieval_utility.log"
else
  echo "[SKIP] Existing retrieval utility: $UTILITY"
fi

if [[ "$RUN_VERIFIER" == "1" ]]; then
  python "$PACKAGE_DIR/scripts/verifier_refresh.py" \
    --repo "$REPO" \
    --old-e2e "$OLD_E2E" \
    --multi "$MULTI" \
    --out "$OUT" \
    --oracle-db "$ORACLE_DB" \
    2>&1 | tee "$OUT/logs/04_unified_verifier_refresh.log"
else
  echo "[SKIP] Unified verifier refresh not enabled."
  echo "       Re-run with: RUN_VERIFIER=1 bash run_all.sh"
fi

python "$PACKAGE_DIR/scripts/collect_results.py" \
  --old-e2e "$OLD_E2E" \
  --multi "$MULTI" \
  --out "$OUT" \
  --verifier-required "$RUN_VERIFIER" \
  2>&1 | tee "$OUT/logs/05_collect_results.log"

python "$PACKAGE_DIR/scripts/make_review_bundle.py" --out "$OUT"

echo "[DONE] $(date -u +%FT%TZ)"
echo "[RETURN FILE] $OUT/conditional_nll_results_for_review_20260828.tar.gz"
sha256sum "$OUT/conditional_nll_results_for_review_20260828.tar.gz"
