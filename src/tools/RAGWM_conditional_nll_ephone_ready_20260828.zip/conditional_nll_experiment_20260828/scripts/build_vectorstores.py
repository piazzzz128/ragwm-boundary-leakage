#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gc
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

import chromadb
import torch


POINTS = ("fpr01", "fpr025", "fpr05", "fpr10")
COLLECTION = "nfcorpus_contriever_cosine"


def read_jsonl(path: Path):
    with path.open(encoding="utf-8") as h:
        return [json.loads(line) for line in h if line.strip()]


def atomic_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)


def count_db(path: Path) -> int | None:
    if not path.is_dir():
        return None
    try:
        return int(chromadb.PersistentClient(path=str(path)).get_collection(COLLECTION).count())
    except Exception:
        return None


def main():
    p = argparse.ArgumentParser(); p.add_argument("--repo", required=True); p.add_argument("--out", type=Path, required=True); p.add_argument("--batch-size", type=int, default=32)
    args = p.parse_args()
    import sys
    sys.path.insert(0, args.repo)
    from src.utils import load_models

    todo = []
    for point in POINTS:
        corpus = args.out / "conditions" / f"conditional_nll_{point}" / "sanitization" / "conditional_nll_sanitized_corpus.jsonl"
        db = args.out / "vectorstores" / f"conditional_nll_{point}"
        summary = args.out / "vectorstores" / f"conditional_nll_{point}_build_summary.json"
        if not corpus.exists(): raise FileNotFoundError(corpus)
        if count_db(db) == 3633:
            print(f"[SKIP] Complete vectorstore {point}: {db}"); continue
        if db.exists():
            quarantine = args.out / "quarantine" / f"{db.name}_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
            quarantine.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(db), str(quarantine))
            print(f"[QUARANTINE] Incomplete vectorstore moved to {quarantine}")
        todo.append((point, corpus, db, summary))
    if not todo:
        print("ALL CONDITIONAL NLL VECTORSTORES ALREADY COMPLETE"); return

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, _, tokenizer, get_emb = load_models("contriever")
    model.eval(); model.to(device)
    for point, corpus, db, summary in todo:
        rows = read_jsonl(corpus)
        if len(rows) != 3633: raise RuntimeError(f"{point}: expected 3633 rows, got {len(rows)}")
        tmp = db.with_name(db.name + f".building_{os.getpid()}")
        tmp.mkdir(parents=True, exist_ok=False)
        client = chromadb.PersistentClient(path=str(tmp))
        collection = client.create_collection(name=COLLECTION, metadata={"hnsw:space": "cosine"})
        for start in range(0, len(rows), args.batch_size):
            batch = rows[start:start + args.batch_size]
            texts = [r["text"] for r in batch]
            tokenized = tokenizer(texts, padding=True, truncation=True, return_tensors="pt")
            tokenized = {k: v.to(device) for k, v in tokenized.items()}
            with torch.no_grad(): embeddings = get_emb(model, tokenized).detach().cpu().tolist()
            collection.add(
                ids=[str(r["internal_id"]) for r in batch], documents=texts, embeddings=embeddings,
                metadatas=[{"id": str(r["source_doc_id"]), "title": str(r.get("title", "")), "change": False, "sanitization": "conditional_nll_same_position_suffix"} for r in batch],
            )
            if (start + len(batch)) % 320 == 0 or start + len(batch) == len(rows): print(f"{point}: embedded {start + len(batch)}/{len(rows)}", flush=True)
        count = int(collection.count())
        if count != 3633: raise RuntimeError(f"{point}: vectorstore count {count}")
        del collection, client; gc.collect()
        os.replace(tmp, db)
        atomic_json(summary, {"experiment_role": "conditional_nll_same_position_multibudget", "budget_id": point, "database": str(db), "collection": COLLECTION, "count": count, "retriever": "contriever", "distance": "cosine"})
        print(f"[PASS] {point} vectorstore: {db}")
    print("CONDITIONAL NLL VECTORSTORE BUILD PASS")


if __name__ == "__main__": main()
