#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path


POINTS = ("fpr01", "fpr025", "fpr05", "fpr10")


def load(path: Path): return json.loads(path.read_text(encoding="utf-8"))


def atomic(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True); tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"); os.replace(tmp, path)


def exact_mcnemar(b: int, c: int) -> float:
    n = b + c
    if n == 0: return 1.0
    tail = sum(math.comb(n, i) for i in range(min(b, c) + 1)) / (2**n)
    return min(1.0, 2.0 * tail)


def verify_map(path: Path):
    rows = load(path); mapping = {tuple(r[0]): int(r[2][0]) for r in rows}
    if len(rows) != 30 or len(mapping) != 30 or any(v not in (0, 1) for v in mapping.values()): raise RuntimeError(f"Invalid verifier file: {path}")
    return mapping


def paired(ref, other):
    if set(ref) != set(other): raise RuntimeError("Verifier watermark-unit sets differ")
    b = sum(ref[k] == 1 and other[k] == 0 for k in ref); c = sum(ref[k] == 0 and other[k] == 1 for k in ref)
    return {"wsn": sum(other.values()), "yes_to_no": b, "no_to_yes": c, "mcnemar_exact_two_sided_p": exact_mcnemar(b, c), "paired_attack_success_rate_among_baseline_positive": b / sum(ref.values()) if sum(ref.values()) else None}


def main():
    p = argparse.ArgumentParser(); p.add_argument("--old-e2e", type=Path, required=True); p.add_argument("--multi", type=Path, required=True); p.add_argument("--out", type=Path, required=True); p.add_argument("--verifier-required", default="0")
    args = p.parse_args()
    score_report = load(args.out / "localization/nfcorpus_same_position_current_report.json")
    threshold_manifest = load(args.out / "thresholds/conditional_nll_threshold_manifest.json")
    utility = load(args.out / "metrics/retrieval_utility_frozen.json")
    report = {"status": "gpu_and_retrieval_complete", "localization": score_report, "threshold_manifest": threshold_manifest, "conditional_nll_budgets": {}, "retrieval_utility": utility}
    for point in POINTS:
        report["conditional_nll_budgets"][point] = load(args.out / f"conditions/conditional_nll_{point}/sanitization/conditional_nll_sanitization_summary.json")
    verifier_root = args.out / "verifier_refresh/conditions"
    if (args.out / "verifier_refresh/campaign_manifest_complete.json").exists():
        files = {p.relative_to(verifier_root).parts[0]: p for p in verifier_root.glob("*/basepath/wm_generate/nfcorpus/gpt4o_mini_e2e/10/wmuint_verify.json")}
        expected = {"watermarked", "oracle_restore"} | {f"gainratio_{p}" for p in POINTS} | {f"conditional_nll_{p}" for p in POINTS} | {f"random_fpr05_seed{s}" for s in (101,202,303,404,505)}
        if set(files) != expected: raise RuntimeError(f"Unified verifier file set mismatch: missing={sorted(expected-set(files))}, extra={sorted(set(files)-expected)}")
        maps = {name: verify_map(path) for name, path in files.items()}; base = maps["watermarked"]; oracle = maps["oracle_restore"]
        verifier = {"watermarked_wsn": sum(base.values()), "oracle_wsn": sum(oracle.values()), "conditions_vs_watermarked": {}}
        for name, mapping in maps.items():
            if name != "watermarked": verifier["conditions_vs_watermarked"][name] = paired(base, mapping)
        verifier["conditional_vs_gainratio_same_budget"] = {}
        for point in POINTS:
            verifier["conditional_vs_gainratio_same_budget"][point] = paired(maps[f"gainratio_{point}"], maps[f"conditional_nll_{point}"])
        random_wsns = [sum(maps[f"random_fpr05_seed{s}"].values()) for s in (101,202,303,404,505)]
        verifier["random_fpr05_wsn"] = {"values": random_wsns, "mean": sum(random_wsns)/len(random_wsns), "min": min(random_wsns), "max": max(random_wsns)}
        report["unified_verifier"] = verifier; report["status"] = "complete"
    elif args.verifier_required == "1":
        raise RuntimeError("Verifier was required but unified campaign is incomplete")
    else:
        report["unified_verifier"] = None
    report["interpretation_guard"] = [
        "Use only same-position target-token results in the manuscript.",
        "Do not mix verifier endpoints from different provider campaigns.",
        "Do not select a threshold using WSN or retrieval utility.",
        "Report Conditional NLL as a simple baseline; GainRatio superiority is supported only where paired evidence or strict-FPR behavior supports it.",
    ]
    atomic(args.out / "metrics/conditional_nll_complete_report.json", report)
    print(json.dumps({"status": report["status"], "conditional_localization": score_report["metrics"]["conditional_nll"], "budget_edits": {p: {"documents": report["conditional_nll_budgets"][p]["modified_document_count"], "characters": report["conditional_nll_budgets"][p]["total_deleted_chars"]} for p in POINTS}, "unified_verifier": report["unified_verifier"]}, ensure_ascii=False, indent=2))
    print("CONDITIONAL NLL RESULT COLLECTION PASS")


if __name__ == "__main__": main()
