#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import os
import tarfile
from pathlib import Path


def sha(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""): h.update(chunk)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser(); p.add_argument("--out", type=Path, required=True); args = p.parse_args()
    patterns = [
        "audit/*.json", "localization/*.json", "thresholds/*.json", "metrics/*.json",
        "conditions/*/sanitization/*summary.json", "vectorstores/*_build_summary.json",
        "verifier_refresh/campaign_manifest*.json",
        "verifier_refresh/conditions/*/basepath/wm_generate/nfcorpus/gpt4o_mini_e2e/10/wmuint_verify.json",
    ]
    files = sorted({f for pattern in patterns for f in args.out.glob(pattern) if f.is_file()})
    if not files: raise RuntimeError("No formal result files found")
    manifest = args.out / "SHA256SUMS_formal_results.txt"
    manifest.write_text("".join(f"{sha(f)}  {f.relative_to(args.out)}\n" for f in files), encoding="utf-8")
    bundle = args.out / "conditional_nll_results_for_review_20260828.tar.gz"
    with tarfile.open(bundle, "w:gz") as tar:
        for f in files + [manifest]: tar.add(f, arcname=str(f.relative_to(args.out)))
    print(f"Review bundle: {bundle}")
    print(f"SHA-256: {sha(bundle)}")


if __name__ == "__main__": main()

