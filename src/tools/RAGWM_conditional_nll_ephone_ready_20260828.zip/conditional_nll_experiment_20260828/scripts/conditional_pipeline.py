#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import tempfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import sklearn
import torch
import transformers
from sklearn.metrics import average_precision_score, precision_recall_curve, roc_auc_score, roc_curve

from e2_common_aligned import (
    last_eligible_sentence_span,
    load_qwen_model,
    norm_space,
    read_jsonl,
    sha256_file,
    tail_context,
    target_nll_aligned,
    write_json_atomic,
    write_jsonl,
)

EXPECTED_SCORE_SHA = "e1c7dbc745a83b473883ccf9c0d6a3c43c1bb7a14fa9f0dda1551b08f92dd218"
EXPECTED_INPUT_SHA = "52c72f64043e4a668b5084b75ac0cfa92f63b77c3493875cf788ee5021da8e38"
BUDGETS = (("fpr01", 0.01), ("fpr025", 0.025), ("fpr05", 0.05), ("fpr10", 0.10))


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as h:
        json.dump(value, h, ensure_ascii=False, indent=2)
        h.write("\n")
        tmp = Path(h.name)
    os.replace(tmp, path)


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def bucket(group_id: str, seed: int) -> float:
    value = int(hashlib.sha256(f"{seed}|{group_id}".encode()).hexdigest()[:16], 16)
    return value / float(16**16 - 1)


def quantile_higher(values: np.ndarray, q: float) -> float:
    try:
        return float(np.quantile(values, q, method="higher"))
    except TypeError:
        return float(np.quantile(values, q, interpolation="higher"))


def metric_block(y: np.ndarray, s: np.ndarray) -> dict[str, float]:
    fpr, tpr, _ = roc_curve(y, s)
    precision, recall, _ = precision_recall_curve(y, s)
    f1 = 2 * precision * recall / np.maximum(precision + recall, 1e-15)
    result = {
        "roc_auc": float(roc_auc_score(y, s)),
        "pr_auc": float(average_precision_score(y, s)),
        "best_f1": float(np.nanmax(f1)),
    }
    for point in (0.01, 0.05, 0.10):
        valid = tpr[fpr <= point + 1e-15]
        result[f"tpr_at_fpr_{point:g}"] = float(valid.max()) if len(valid) else 0.0
    return result


def cluster_bootstrap(rows: list[dict[str, Any]], n_boot: int, seed: int) -> dict[str, Any]:
    groups: dict[str, list[int]] = defaultdict(list)
    for i, row in enumerate(rows):
        group = str(row.get("source_doc_id") or row.get("group_id") or row.get("id"))
        groups[group].append(i)
    keys = sorted(groups)
    rng = np.random.default_rng(seed)
    samples = {"roc_auc_difference_conditional_minus_gainratio": [], "pr_auc_difference_conditional_minus_gainratio": []}
    y_all = np.asarray([int(r["label"]) for r in rows])
    cond_all = np.asarray([float(r["conditional_nll_current"]) for r in rows])
    gain_all = np.asarray([float(r["gainratio_current"]) for r in rows])
    for _ in range(n_boot):
        draw = rng.choice(keys, size=len(keys), replace=True)
        idx = [i for key in draw for i in groups[key]]
        y = y_all[idx]
        if len(np.unique(y)) != 2:
            continue
        cond, gain = cond_all[idx], gain_all[idx]
        samples["roc_auc_difference_conditional_minus_gainratio"].append(float(roc_auc_score(y, cond) - roc_auc_score(y, gain)))
        samples["pr_auc_difference_conditional_minus_gainratio"].append(float(average_precision_score(y, cond) - average_precision_score(y, gain)))
    output: dict[str, Any] = {"replicates_requested": n_boot, "seed": seed, "cluster_count": len(keys)}
    for name, vals in samples.items():
        arr = np.asarray(vals, dtype=float)
        output[name] = {
            "replicates_valid": int(len(arr)),
            "mean": float(arr.mean()),
            "ci95_percentile": [float(np.quantile(arr, 0.025)), float(np.quantile(arr, 0.975))],
        }
    return output


def rescore_boundaries(args, tokenizer, model, device) -> tuple[Path, dict[str, Any]]:
    out = args.out / "localization"
    out.mkdir(parents=True, exist_ok=True)
    path = out / "nfcorpus_same_position_current_scores.json"
    report_path = out / "nfcorpus_same_position_current_report.json"
    frozen = load_json(args.scores)
    if len(frozen) != 446 or Counter(int(r["label"]) for r in frozen) != Counter({0: 223, 1: 223}):
        raise RuntimeError("Frozen boundary set must contain 446 rows with labels 223/223")
    if path.exists():
        rows = load_json(path)
        if len(rows) != 446:
            raise RuntimeError("Existing current-score file is incomplete; use a new OUT path")
        print(f"[SKIP] Complete current score file: {path}")
    else:
        rows = []
        for i, old in enumerate(frozen):
            context = str(old.get("context") or old.get("context_text") or "")
            target = str(old.get("target") or old.get("target_text") or "")
            target_nll = target_nll_aligned(tokenizer, model, device, "", target)
            conditional = target_nll_aligned(tokenizer, model, device, context, target)
            if target_nll is None or conditional is None or target_nll <= 0:
                raise RuntimeError(f"Invalid loss at boundary row {i}")
            gainratio = -((target_nll - conditional) / target_nll)
            row = dict(old)
            row.update({
                "target_nll_current": float(target_nll),
                "conditional_nll_current": float(conditional),
                "gainratio_current": float(gainratio),
                "same_target_positions": "t2_through_tn_in_both_losses",
                "no_bos": True,
                "no_separator": True,
            })
            rows.append(row)
            if (i + 1) % 25 == 0 or i + 1 == len(frozen):
                print(f"rescored boundary {i + 1}/{len(frozen)}", flush=True)
        atomic_json(path, rows)

    y = np.asarray([int(r["label"]) for r in rows])
    target = np.asarray([float(r["target_nll_current"]) for r in rows])
    cond = np.asarray([float(r["conditional_nll_current"]) for r in rows])
    gain = np.asarray([float(r["gainratio_current"]) for r in rows])
    old_target = np.asarray([float(r["loss_target_aligned"]) for r in rows])
    old_cond = np.asarray([float(r["loss_target_given_context_aligned"]) for r in rows])
    old_gain = np.asarray([float(r["score_aligned"]) for r in rows])
    report = {
        "experiment_role": "same_position_conditional_nll_baseline",
        "record_count": len(rows),
        "labels": dict(Counter(map(str, y.tolist()))),
        "score_direction": "larger_is_more_suspicious",
        "metrics": {
            "target_only_nll": metric_block(y, target),
            "conditional_nll": metric_block(y, cond),
            "gainratio_recomputed_same_environment": metric_block(y, gain),
        },
        "full_environment_parity": {
            "target_max_abs_error": float(np.max(np.abs(target - old_target))),
            "target_mean_abs_error": float(np.mean(np.abs(target - old_target))),
            "conditional_max_abs_error": float(np.max(np.abs(cond - old_cond))),
            "conditional_mean_abs_error": float(np.mean(np.abs(cond - old_cond))),
            "gainratio_max_abs_error": float(np.max(np.abs(gain - old_gain))),
            "gainratio_mean_abs_error": float(np.mean(np.abs(gain - old_gain))),
            "conditional_pearson": float(np.corrcoef(cond, old_cond)[0, 1]),
            "gainratio_pearson": float(np.corrcoef(gain, old_gain)[0, 1]),
        },
        "paired_source_document_cluster_bootstrap": cluster_bootstrap(rows, args.n_boot, 20260828),
        "current_scores": str(path),
        "current_scores_sha256": sha256_file(path),
        "frozen_scores": str(args.scores),
        "frozen_scores_sha256": sha256_file(args.scores),
        "environment": {
            "python": platform.python_version(), "torch": torch.__version__,
            "transformers": transformers.__version__, "numpy": np.__version__,
            "sklearn": sklearn.__version__, "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        },
    }
    atomic_json(report_path, report)
    return path, report


def freeze_thresholds(args, score_path: Path) -> dict[str, Any]:
    rows = load_json(score_path)
    clean_groups: dict[str, list[float]] = defaultdict(list)
    inject_scores = []
    for row in rows:
        if int(row["label"]) == 0:
            group = str(row.get("source_doc_id") or row.get("group_id") or row.get("id"))
            clean_groups[group].append(float(row["conditional_nll_current"]))
        else:
            inject_scores.append(float(row["conditional_nll_current"]))
    cal_groups = {g for g in clean_groups if bucket(g, args.seed) < 0.70}
    hold_groups = set(clean_groups) - cal_groups
    cal = np.asarray([v for g in cal_groups for v in clean_groups[g]], dtype=float)
    hold = np.asarray([v for g in hold_groups for v in clean_groups[g]], dtype=float)
    inj = np.asarray(inject_scores, dtype=float)
    if len(cal) != 169 or len(hold) != 54:
        raise RuntimeError(f"Expected 169/54 clean calibration/holdout rows, got {len(cal)}/{len(hold)}")
    threshold_dir = args.out / "thresholds"
    threshold_dir.mkdir(parents=True, exist_ok=True)
    points = []
    for name, fpr in BUDGETS:
        threshold = quantile_higher(cal, 1.0 - fpr)
        item = {
            "method": "conditional_nll",
            "budget_id": name,
            "target_clean_fpr": fpr,
            "threshold": threshold,
            "score_direction": "larger_is_more_suspicious",
            "same_target_positions": "t2_through_tn",
            "seed": args.seed,
            "group_split": True,
            "calibration_fraction": 0.70,
            "calibration_group_count": len(cal_groups),
            "holdout_group_count": len(hold_groups),
            "calibration_record_count": len(cal),
            "holdout_record_count": len(hold),
            "calibration_empirical_fpr": float(np.mean(cal >= threshold)),
            "holdout_empirical_fpr": float(np.mean(hold >= threshold)),
            "diagnostic_injected_tpr": float(np.mean(inj >= threshold)),
            "score_file": str(score_path),
            "score_file_sha256": sha256_file(score_path),
            "freeze_guard": "threshold_not_tuned_with_verifier_or_retrieval_utility",
        }
        file = threshold_dir / f"conditional_nll_threshold_{name}.json"
        atomic_json(file, item)
        item["threshold_file"] = str(file)
        item["threshold_file_sha256"] = sha256_file(file)
        points.append(item)
    manifest = {
        "experiment_role": "conditional_nll_same_position_multibudget",
        "points": points,
        "nested_thresholds": all(points[i]["threshold"] >= points[i + 1]["threshold"] for i in range(len(points) - 1)),
    }
    if not manifest["nested_thresholds"]:
        raise RuntimeError("Conditional-NLL thresholds are not nested")
    manifest_path = threshold_dir / "conditional_nll_threshold_manifest.json"
    atomic_json(manifest_path, manifest)
    return manifest


def scan_one(row: dict[str, Any], index: int, tokenizer, model, device, min_threshold: float, max_steps: int, campaign: str) -> dict[str, Any]:
    original = row["text"]
    current = original
    candidates = []
    stop = "max_steps_reached"
    for step in range(1, max_steps + 1):
        span = last_eligible_sentence_span(current)
        if span is None:
            stop = "no_eligible_sentence"; break
        start, end = span
        target = norm_space(current[start:end])
        context = tail_context(current[:start])
        if not context:
            stop = "empty_context"; break
        score = target_nll_aligned(tokenizer, model, device, context, target)
        if score is None:
            stop = "invalid_loss"; break
        retained = current[:start].rstrip()
        candidates.append({
            "step": step, "boundary_start": start, "boundary_end": end,
            "context": context, "target": target, "conditional_nll": float(score),
            "retained_text": retained,
        })
        if float(score) < min_threshold:
            stop = "below_most_permissive_threshold"; break
        current = retained
        stop = "deleted_and_continue"
    return {
        "campaign_id": campaign, "input_index": index,
        "internal_id": row["internal_id"], "source_doc_id": row["source_doc_id"],
        "title": row.get("title", ""), "original_text": original,
        "candidate_evaluations": candidates, "scan_stop_reason": stop,
    }


def scan_and_derive(args, tokenizer, model, device, manifest: dict[str, Any], score_path: Path) -> None:
    rows = read_jsonl(args.input)
    if len(rows) != 3633:
        raise RuntimeError(f"Expected 3,633 corpus documents, got {len(rows)}")
    forbidden = {"change", "label", "watermark_text", "tuple"}
    for i, row in enumerate(rows):
        leaked = forbidden.intersection(row)
        if leaked:
            raise RuntimeError(f"Ground-truth field leak at input row {i}: {sorted(leaked)}")
        for key in ("internal_id", "source_doc_id", "text"):
            if key not in row:
                raise RuntimeError(f"Missing {key} at input row {i}")
    points = {p["budget_id"]: p for p in manifest["points"]}
    min_threshold = min(float(p["threshold"]) for p in points.values())
    campaign = hashlib.sha256((sha256_file(args.input) + sha256_file(score_path) + json.dumps({k: points[k]["threshold"] for k in sorted(points)}, sort_keys=True)).encode()).hexdigest()
    record_dir = args.out / "scan_records"
    record_dir.mkdir(parents=True, exist_ok=True)
    for i, row in enumerate(rows):
        path = record_dir / f"{i:05d}.json"
        if path.exists():
            old = load_json(path)
            if old.get("campaign_id") != campaign or old.get("internal_id") != row["internal_id"]:
                raise RuntimeError(f"Resume guard failed at {path}; use a new OUT path")
            continue
        atomic_json(path, scan_one(row, i, tokenizer, model, device, min_threshold, args.max_steps, campaign))
        if (i + 1) % 25 == 0 or i + 1 == len(rows):
            print(f"scanned corpus {i + 1}/{len(rows)}", flush=True)
        if torch.cuda.is_available() and (i + 1) % 200 == 0:
            torch.cuda.empty_cache()
    files = sorted(record_dir.glob("*.json"))
    if len(files) != len(rows):
        raise RuntimeError(f"Incomplete scan records: {len(files)}/{len(rows)}")
    records = [load_json(p) for p in files]
    if [r["input_index"] for r in records] != list(range(len(rows))):
        raise RuntimeError("Scan-record index integrity failure")

    for budget_id, point in points.items():
        threshold = float(point["threshold"])
        outdir = args.out / "conditions" / f"conditional_nll_{budget_id}" / "sanitization"
        sanitized_rows, deletion_rows, candidate_rows = [], [], []
        modified = deleted_chars = steps = 0
        stops = Counter()
        for record in records:
            current = record["original_text"]
            selected = []
            reason = record["scan_stop_reason"]
            for candidate in record["candidate_evaluations"]:
                candidate_rows.append({
                    "internal_id": record["internal_id"], "source_doc_id": record["source_doc_id"],
                    "budget_id": budget_id, "threshold": threshold,
                    **{k: v for k, v in candidate.items() if k != "retained_text"},
                })
                if float(candidate["conditional_nll"]) >= threshold:
                    current = candidate["retained_text"]
                    selected.append(candidate)
                else:
                    reason = "score_below_threshold"; break
            changed = current != record["original_text"]
            deleted = len(record["original_text"]) - len(current)
            modified += int(changed); deleted_chars += deleted; steps += len(selected); stops[reason] += 1
            sanitized_rows.append({"internal_id": record["internal_id"], "source_doc_id": record["source_doc_id"], "title": record.get("title", ""), "text": current})
            if changed:
                deletion_rows.append({
                    "internal_id": record["internal_id"], "source_doc_id": record["source_doc_id"],
                    "original_char_count": len(record["original_text"]), "sanitized_char_count": len(current),
                    "deleted_char_count": deleted, "deletion_step_count": len(selected),
                    "selected": [{k: v for k, v in c.items() if k != "retained_text"} for c in selected],
                })
        corpus = outdir / "conditional_nll_sanitized_corpus.jsonl"
        candidates = outdir / "conditional_nll_candidate_scores.jsonl"
        deletions = outdir / "conditional_nll_deletion_log.jsonl"
        write_jsonl(corpus, sanitized_rows); write_jsonl(candidates, candidate_rows); write_jsonl(deletions, deletion_rows)
        total_chars = sum(len(r["original_text"]) for r in records)
        summary = {
            "experiment_role": "conditional_nll_same_position_multibudget",
            "budget_id": budget_id, "target_clean_fpr": point["target_clean_fpr"], "threshold": threshold,
            "same_target_positions": "t2_through_tn", "max_steps": args.max_steps,
            "input_document_count": len(rows), "completed_document_count": len(records), "complete": True,
            "modified_document_count": modified, "modified_document_rate": modified / len(rows),
            "deletion_step_count": steps, "total_original_chars": total_chars,
            "total_deleted_chars": deleted_chars, "deleted_char_rate": deleted_chars / total_chars,
            "stop_reason_counts": dict(stops), "sanitized_corpus": str(corpus),
            "sanitized_corpus_sha256": sha256_file(corpus), "candidate_scores_sha256": sha256_file(candidates),
            "deletion_log_sha256": sha256_file(deletions), "campaign_id": campaign,
            "derivation_note": "one permissive scan; exact nested-threshold stopping derived for each budget",
        }
        atomic_json(outdir / "conditional_nll_sanitization_summary.json", summary)
        print(json.dumps({"budget": budget_id, "modified_docs": modified, "deleted_chars": deleted_chars, "steps": steps}, ensure_ascii=False))


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--scores", type=Path, required=True); p.add_argument("--input", type=Path, required=True)
    p.add_argument("--model", required=True); p.add_argument("--out", type=Path, required=True)
    p.add_argument("--seed", type=int, default=20260714); p.add_argument("--n-boot", type=int, default=5000)
    p.add_argument("--max-steps", type=int, default=8)
    args = p.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if sha256_file(args.scores) != EXPECTED_SCORE_SHA: raise RuntimeError("Frozen-score SHA mismatch")
    if sha256_file(args.input) != EXPECTED_INPUT_SHA: raise RuntimeError("Attack-input SHA mismatch")
    tokenizer, model, device = load_qwen_model(args.model)
    score_path, report = rescore_boundaries(args, tokenizer, model, device)
    manifest = freeze_thresholds(args, score_path)
    print(json.dumps({"localization_metrics": report["metrics"], "thresholds": {p["budget_id"]: p["threshold"] for p in manifest["points"]}}, ensure_ascii=False, indent=2))
    scan_and_derive(args, tokenizer, model, device, manifest, score_path)
    print("CONDITIONAL NLL SCORE/CALIBRATION/SANITIZATION PASS")


if __name__ == "__main__":
    main()

